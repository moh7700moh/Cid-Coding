import re
import time
import os
import ast
import threading
import tkinter as tk
from tkinter import filedialog

# Initialize Pygame Mixer safely for multi-channel audio
try:
    import pygame
    pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
    AUDIO_READY = True
except ImportError:
    AUDIO_READY = False
    print("[Warning] pygame not installed. Audio actions will run in Simulation Mode.")

def safe_cid_eval(expr):
    try:
        expr_clean = expr.replace('#', '').strip()
        node = ast.parse(expr_clean, mode='eval')
        if isinstance(node, ast.Expression):
            return eval(compile(node, "<cid_runtime>", "eval"), {"__builtins__": None}, {})
    except Exception:
        if expr in ["True", "False"]: return expr == "True"
    return False

def _execute_sequence(files, delays):
    """Background thread worker to execute sequential audio triggers with front delays."""
    for file_path, delay in zip(files, delays):
        if delay > 0:
            time.sleep(delay)
        
        file_clean = file_path.strip()
        print(f"[Sequence Thread] Triggering: '{file_clean}'")
        
        if AUDIO_READY and os.path.exists(file_clean):
            try:
                pygame.mixer.Sound(file_clean).play()
            except Exception as e:
                print(f"[Audio Error] Could not play sequence asset '{file_clean}': {e}")
        else:
            print(f"[Audio Sim] Play: '{file_clean}'")

def run_cid_code(raw_code, output_widget=None):
    def cid_print(txt):
        if output_widget:
            output_widget.insert("end", str(txt) + "
")
            output_widget.see("end")
            output_widget.update_idletasks()
        else:
            print(txt)

    def trigger_asset_popup(mode):
        root = tk.Tk(); root.withdraw()
        is_2d = mode == "2D"
        title = f"Cid Engine: Select your {mode} Asset"
        types = [("2D Image Files", "*.png *.jpg *.jpeg *.bmp")] if is_2d else [("3D Assets", "*.blend *.fbx *.obj *.gltf *.vox")]
        exts = ['.png', '.jpg', '.jpeg', '.bmp'] if is_2d else ['.blend', '.fbx', '.obj', '.gltf', '.vox']
        
        path = filedialog.askopenfilename(title=title, filetypes=types)
        if not path: return "NoFileLoaded"
        if os.path.splitext(path.lower())[1] not in exts:
            cid_print("\n[Cid Runtime Error]\nInvalidFile\n -> Execution terminated.")
            return "CRASH_INVALID_FILE"
        filename = os.path.basename(path)
        cid_print(f"[Asset Engine] Linked {mode}: '{filename}'")
        return filename

    # PHASE 1: LINTER
    for idx, line in enumerate(raw_code.split('\n'), 1):
        line_strip = line.strip()
        if not line_strip or line_strip.startswith('%'): continue
        
        if any(x in line for x in ["to  The", "set  ", "  add", "  sub", "So  "]):
            cid_print(f"\n[Cid Compiler Error]\nLine {idx}: Accidental extra space."); return False
            
        if "The " in line_strip and not line_strip.endswith("#") and "/" not in line_strip and not line_strip.startswith("set playerStats"):
            if not any(m in line_strip for m in ["#", "{", "["]):
                cid_print(f"\n[Cid Compiler Error]\nLine {idx}: Missing '#' marker."); return False
                
    cid_print("\n[Cid Linter] Pre-check passed perfectly! Executing...")
    cid_vars = {}
    cond_stack = [] 
    current_executing = True

    def resolve(expr):
        if " #" in expr or expr.endswith("#"):
            expr = expr.rsplit("#", 1)[0].strip()
            
        for k in sorted(cid_vars.keys(), key=len, reverse=True):
            v = cid_vars[k]
            v_str = str([f"The {x}#" if isinstance(x, str) else x for x in v]).replace("'", "") if isinstance(v, list) else str(v)
            expr = expr.replace(f"Find - {k}", v_str)
        return expr

    # PHASE 2 & 3: PARSING
    for idx, line in enumerate(raw_code.split('\n'), 1):
        clean = line.strip()
        if not clean or clean.startswith('%'): continue
        
        if clean == "finish":
            current_executing = cond_stack.pop() if cond_stack else True
            continue
        if clean == "next":
            if cond_stack: current_executing = not cond_stack[-1]
            continue

        cmds, in_str, cur = [], False, []
        for char in clean:
            if char == "T" and "".join(cur[-3:]) == "The": in_str = True
            if char == "#": in_str = False
            if char == "/" and not in_str:
                cmds.append("".join(cur).strip()); cur = []
            else: cur.append(char)
        if cur: cmds.append("".join(cur).strip())

        for cmd in cmds:
            if not cmd: continue
            
            if cmd.startswith("if "):
                cond_stack.append(current_executing)
                if current_executing: current_executing = safe_cid_eval(resolve(cmd[3:].strip()))
                continue
            elif cmd.startswith("So "):
                if cond_stack and cond_stack[-1]: current_executing = safe_cid_eval(resolve(cmd[3:].strip()))
                continue
            elif cmd == "else":
                if cond_stack: current_executing = not current_executing
                continue

            if not current_executing: continue

            # AUDIO SEQUENCER
            if cmd.startswith("Sequence ") and " withDelays " in cmd:
                try:
                    main_body = cmd[9:].rsplit("#", 1)[0].strip()
                    files_part, delays_part = main_body.split(" withDelays ")
                    
                    resolved_files = ast.literal_eval(resolve(files_part.strip()))
                    resolved_delays = ast.literal_eval(resolve(delays_part.strip()))
                    
                    if len(resolved_files) == len(resolved_delays):
                        seq_thread = threading.Thread(target=_execute_sequence, args=(resolved_files, resolved_delays), daemon=True)
                        seq_thread.start()
                        cid_print(f"[Audio Scheduler] Dynamic sequence started with {len(resolved_files)} tracks.")
                    else:
                        cid_print(f"Runtime Error line {idx}: Sequence count mismatch.")
                except Exception as e:
                    cid_print(f"Runtime Error line {idx}: Malformed Sequence. {e}")
                continue

            # MUSIC PLAY
            elif cmd.startswith("Music(") and ".Play" in cmd:
                m = re.match(r"Music\((.*?)\)\.Play\.(.*)", cmd)
                if m:
                    audio_file = m.group(1).strip()
                    timing_mod = m.group(2).strip()
                    cid_print(f"[Audio System] Playing Track: '{audio_file}' ({timing_mod})")
                    
                    if AUDIO_READY and os.path.exists(audio_file):
                        try:
                            pygame.mixer.Sound(audio_file).play()
                        except Exception as e:
                            cid_print(f"[Mixer Error] Could not load '{audio_file}': {e}")
                    
                    if timing_mod.endswith("Secs"):
                        time.sleep(float(timing_mod.replace("Secs", "")))
                continue

            elif cmd in ["Add*User2dExperience", "Add*User3dExperience"]:
                cid_print(f"[Engine Framework] Viewport Active: {'2D' if '2d' in cmd else '3D'} Mode.")
            elif cmd.startswith("WaitSecs(") and cmd.endswith(")"):
                try: time.sleep(float(cmd[9:-1].strip()))
                except: cid_print(f"Runtime Error line {idx}: Invalid WaitSecs.")
            elif cmd.startswith("show "):
                cid_print(resolve(cmd[5:].strip()))
            
            # LIST ACTIONS (.insert / .pull)
            elif ".insert(" in cmd or ".pull(" in cmd:
                parts = cmd.split(".", 1)
                v_name = parts[0].strip()
                if v_name in cid_vars and isinstance(cid_vars[v_name], list):
                    act = parts[1].strip()
                    if act.startswith("insert(") or act.startswith("insert( "):
                        item = resolve(act[7:-1].strip())
                        if item.startswith("The ") and item.endswith("#"): val = item[4:-1]
                        else:
                            try: val = ast.literal_eval(item)
                            except: val = item
                        cid_vars[v_name].append(val)
                    elif act.startswith("pull(") or act.startswith("pull( "):
                        r_idx = resolve(act[5:-1].strip())
                        extracted = cid_vars[v_name].pop(int(r_idx)) if r_idx else cid_vars[v_name].pop()
                        cid_print(f"[List Action] Pulled: '{extracted}'")

            # VARIABLE SETTING
            elif cmd.startswith("set "):
                expr_parts = cmd[4:].split(" to ", 1)
                if len(expr_parts) == 2:
                    v_name = expr_parts[0].replace("The ", "").strip()
                    expr = expr_parts[1].strip()
                    
                    if expr in ["Add2dFile", "Add3dFile"]:
                        res = trigger_asset_popup("2D" if "2d" in expr else "3D")
                        if res == "CRASH_INVALID_FILE": return False
                        cid_vars[v_name] = res
                    elif expr.startswith("The ") and expr.endswith("#"): 
                        cid_vars[v_name] = expr[4:-1]
                    elif expr.startswith("[") and expr.endswith("]"):
                        lst = []
                        raw_items = expr[1:-1].split(",")
                        for x in raw_items:
                            x = x.strip()
                            if not x: continue
                            if x.startswith("The ") and x.endswith("#"): lst.append(x[4:-1])
                            else:
                                try: lst.append(ast.literal_eval(x))
                                except: lst.append(x)
                        cid_vars[v_name] = lst
                    else:
                        m_expr = resolve(expr.replace(" add ", " + ").replace(" sub ", " - ").replace(" multi ", " * ").replace(" div ", " / "))
                        cid_vars[v_name] = safe_cid_eval(m_expr)

    cid_print("\n[Cid Engine] Composition completed successfully.")
    return True